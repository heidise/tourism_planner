# Software Design - Group assignment

**Prototype submission:**  Please check the design documentation pdf-file to find a link to our Figma prototype and to see the descriptions and diagrams of the planned application.

**Mid-term submission:** Design documentation has been moved under /docs. The diagrams from the design documentation are going to get updated once the implemention of backend and frontend is more finished. Parts of the backend and frontend have been implemented so far and our demo will demonstrate the current status of the project.

**Final submission:** Our final design documentation can be found under /docs named as "design_documentation_binary_brains_final_submission". The older version of the design documentation can also be found names as ""design_documentation_binary_brains_previous_submissions".

---
**Running the program:**
Java version 21 or newer is required to run the application.

Run backend:
- `cd binary-brains\backend\tourismPlanner`
- `mvn spring-boot:run`

When running controller listens on port 8080

---
Run frontend:
- `cd binary-brains\frontend`
- `npm i`
- `npm run dev`

Frontend runs on localhost port 3000