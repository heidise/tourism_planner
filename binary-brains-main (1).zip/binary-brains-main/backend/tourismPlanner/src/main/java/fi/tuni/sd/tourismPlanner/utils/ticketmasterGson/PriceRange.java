package fi.tuni.sd.tourismPlanner.utils.ticketmasterGson;

public record PriceRange(String type, String currency, Double min, Double max) {
}

