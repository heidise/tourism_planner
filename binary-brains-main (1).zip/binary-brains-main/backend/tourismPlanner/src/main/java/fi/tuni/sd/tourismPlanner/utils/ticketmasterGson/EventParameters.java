package fi.tuni.sd.tourismPlanner.utils.ticketmasterGson;

public record EventParameters(String city, String type, String startTime, String endTime) {
}
