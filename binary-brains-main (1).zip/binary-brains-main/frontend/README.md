# Welcome to Tourism Planner Frontend Directory!

## Run locally
- To get started run - `npm i`
- To start the dev server - `npm run dev`
- To build for production - `npm run build`
- To check linting - `npm run lint`
- To fix syntax - `npm run prettier`

## Prerequisites
- Have node installed
- Have npm installed

