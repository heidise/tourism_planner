package fi.tuni.sd.tourismPlanner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TourismPlannerApplicationTests {

	@Test
	void contextLoads() {
	}

}
