const weathers = [
  'All',
  'Thunderstorm',
  'Drizzle',
  'Cloudy',
  'Rain',
  'Snow',
  'Atmosphere',
  'Clear',
  'Clouds',
];
export default weathers;
